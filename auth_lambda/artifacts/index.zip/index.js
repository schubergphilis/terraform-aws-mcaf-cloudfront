"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const config_1 = require("./lib/config");
const redirect_1 = require("./lib/redirect");
const callback_1 = require("./lib/callback");
const cookie_1 = require("./lib/cookie");
const verify_1 = require("./lib/verify");
const handler = async (event, context, callback) => {
    console.log("Event: ", JSON.stringify(event));
    const cloudfrontRecord = event.Records[0].cf;
    const request = cloudfrontRecord.request;
    const config = await (0, config_1.getConfig)(cloudfrontRecord.config.distributionId);
    const cookie = (0, cookie_1.getCookie)(request.headers);
    if (request.uri.startsWith("/_callback")) {
        await (0, callback_1.handleCallback)(config, request, callback);
    }
    else if ("TOKEN" in cookie) {
        (0, verify_1.verifyToken)(cookie.TOKEN, config, request, callback);
    }
    else {
        console.log("No authentication session found. Redirecting to Okta...");
        (0, redirect_1.redirect)(config, request, callback);
    }
};
exports.handler = handler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFFQSx5Q0FBdUM7QUFDdkMsNkNBQXdDO0FBQ3hDLDZDQUE4QztBQUM5Qyx5Q0FBdUM7QUFDdkMseUNBQXlDO0FBRWxDLE1BQU0sT0FBTyxHQUFZLEtBQUssRUFDakMsS0FBNkIsRUFDN0IsT0FBZ0IsRUFDaEIsUUFBbUMsRUFDckMsRUFBRTtJQUNBLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUU5QyxNQUFNLGdCQUFnQixHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0lBQzdDLE1BQU0sT0FBTyxHQUFHLGdCQUFnQixDQUFDLE9BQU8sQ0FBQztJQUN6QyxNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUEsa0JBQVMsRUFBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDdkUsTUFBTSxNQUFNLEdBQUcsSUFBQSxrQkFBUyxFQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUUxQyxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxFQUFFO1FBQ3RDLE1BQU0sSUFBQSx5QkFBYyxFQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDLENBQUM7S0FDbkQ7U0FBTSxJQUFJLE9BQU8sSUFBSSxNQUFNLEVBQUU7UUFDMUIsSUFBQSxvQkFBVyxFQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQztLQUN4RDtTQUFNO1FBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQyx5REFBeUQsQ0FBQyxDQUFDO1FBQ3ZFLElBQUEsbUJBQVEsRUFBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLFFBQVEsQ0FBQyxDQUFDO0tBQ3ZDO0FBQ0wsQ0FBQyxDQUFBO0FBcEJZLFFBQUEsT0FBTyxXQW9CbkIifQ==