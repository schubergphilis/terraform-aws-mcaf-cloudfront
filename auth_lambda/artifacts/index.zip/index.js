"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const config_1 = require("./lib/config");
const redirect_1 = require("./lib/redirect");
const callback_1 = require("./lib/callback");
const cookie_1 = require("./lib/cookie");
const verify_1 = require("./lib/verify");
exports.handler = async (event, context, callback) => {
    console.log("Event: ", JSON.stringify(event));
    const cloudfrontRecord = event.Records[0].cf;
    const request = cloudfrontRecord.request;
    const config = await config_1.getConfig(cloudfrontRecord.config.distributionId);
    const cookie = cookie_1.getCookie(request.headers);
    if (request.uri.startsWith("/_callback")) {
        await callback_1.handleCallback(config, request, callback);
    }
    else if ("TOKEN" in cookie) {
        verify_1.verifyToken(cookie.TOKEN, config, request, callback);
    }
    else {
        console.log("No authentication session found. Redirecting to Okta...");
        redirect_1.redirect(config, request, callback);
    }
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUVBLHlDQUF1QztBQUN2Qyw2Q0FBd0M7QUFDeEMsNkNBQThDO0FBQzlDLHlDQUF1QztBQUN2Qyx5Q0FBeUM7QUFFNUIsUUFBQSxPQUFPLEdBQVksS0FBSyxFQUNqQyxLQUE2QixFQUM3QixPQUFnQixFQUNoQixRQUFtQyxFQUNyQyxFQUFFO0lBQ0EsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0lBRTlDLE1BQU0sZ0JBQWdCLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7SUFDN0MsTUFBTSxPQUFPLEdBQUcsZ0JBQWdCLENBQUMsT0FBTyxDQUFDO0lBQ3pDLE1BQU0sTUFBTSxHQUFHLE1BQU0sa0JBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDdkUsTUFBTSxNQUFNLEdBQUcsa0JBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7SUFFMUMsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsRUFBRTtRQUN0QyxNQUFNLHlCQUFjLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQztLQUNuRDtTQUFNLElBQUksT0FBTyxJQUFJLE1BQU0sRUFBRTtRQUMxQixvQkFBVyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQztLQUN4RDtTQUFNO1FBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQyx5REFBeUQsQ0FBQyxDQUFDO1FBQ3ZFLG1CQUFRLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQztLQUN2QztBQUNMLENBQUMsQ0FBQSJ9